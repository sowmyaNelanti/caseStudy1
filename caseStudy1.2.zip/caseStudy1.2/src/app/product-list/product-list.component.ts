import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})
export class ProductListComponent implements OnInit {

noOfButtons;
noOfButtonsArray=[];

productList=[{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
},{
  id:1,
  name:"dove",
  des:"oily",
  price:80
}
]
  constructor() { }

  ngOnInit() {
    this.createDynamicButtons();
  }
createDynamicButtons(){
  this.noOfButtons=Math.ceil(this.productList.length/5)
  
  for(var i=0;i<this.noOfButtons;i++){
    var button={
      "id":"button"+i,
      "index":i
    }
    console.log(button);
    this.noOfButtonsArray.push(i+1);
  }
 
}



  
  
 

}
